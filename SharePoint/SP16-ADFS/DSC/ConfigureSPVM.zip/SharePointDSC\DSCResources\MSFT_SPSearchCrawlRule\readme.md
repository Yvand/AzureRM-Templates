# Description

This resource is responsible for managing the search crawl rules in the search
service application. You can create new rules, change existing rules and remove
existing rules.
