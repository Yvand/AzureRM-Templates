**Description**

This resource is responsible for creating Excel Services Application instances 
within the local SharePoint farm. The resource will provision and configure the 
Excel Services Service Application.
