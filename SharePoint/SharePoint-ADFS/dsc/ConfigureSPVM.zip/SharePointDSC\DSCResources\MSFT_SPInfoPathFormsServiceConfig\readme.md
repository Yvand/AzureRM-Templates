# Description

This resource is responsible for configuring the InfoPath Forms service within
the local SharePoint farm. Using Ensure equals to Absent is not supported.
This resource can only apply configuration, not ensure they don't exist.
