# Description

**Type:** Distributed

This resource is responsible for creating Access Services Application instances
within the local SharePoint farm. The resource will provision and configure the
Access Services Service Application.

The default value for the Ensure parameter is Present. When not specifying this
parameter, the service application is provisioned.
