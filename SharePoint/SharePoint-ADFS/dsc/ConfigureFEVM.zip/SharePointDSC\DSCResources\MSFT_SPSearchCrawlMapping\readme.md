# Description

This resource is responsible for managing the search crawl mapping in the
search service application. You can create new mappings, change existing mappings
and remove existing mappings.

The default value for the Ensure parameter is Present. When you omit this
parameter the crawl rule is created.
