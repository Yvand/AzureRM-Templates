# Description

Allows you to configure the default timesheet settings for a specific PWA
instance.
