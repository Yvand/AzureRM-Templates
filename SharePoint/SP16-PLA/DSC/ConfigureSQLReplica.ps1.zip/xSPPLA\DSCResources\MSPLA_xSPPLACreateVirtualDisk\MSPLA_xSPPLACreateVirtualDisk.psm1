#
# xSPPLACreateVirtualDisk: DSC resource to create a virtual disk in a new storage pool
#

function Get-TargetResource
{
    [OutputType([System.Collections.Hashtable])]
    param
    (
        [parameter(Mandatory = $true)] [System.String] $StoragePoolName,
        [parameter(Mandatory = $true)] [System.String] $VirtualDiskName,
        [parameter(Mandatory = $true)] [System.UInt64] $NumberOfDisks,
        [parameter(Mandatory = $true)] [System.String] $DriveLetter,
        [ValidateNotNullOrEmpty()] [Bool]$RebootVirtualMachine = $false 
    )
    
    $bConfigured = Test-TargetResource -StoragePoolName $StoragePoolName -VirtualDiskName $VirtualDiskName -NumberOfDisks $NumberOfDisks -DriveLetter $DriveLetter

    $retVal = @{
        StoragePoolName = $StoragePoolName
        VirtualDiskName = $VirtualDiskName 
        NumberOfDisks = $NumberOfDisks 
        DriveLetter = $DriveLetter
        Configured = $bConfigured
    }

    $retVal
}

function Set-TargetResource
{
    param
    (
        [parameter(Mandatory = $true)] [System.String] $StoragePoolName,
        [parameter(Mandatory = $true)] [System.String] $VirtualDiskName,
        [parameter(Mandatory = $true)] [System.UInt64] $NumberOfDisks,
        [parameter(Mandatory = $true)] [System.String] $DriveLetter,
        [ValidateNotNullOrEmpty()] [Bool]$RebootVirtualMachine = $false 
    )

    $availabledisks = Get-PhysicalDisk -CanPool $true | Sort-Object {$_.DeviceId}

    if ($availabledisks.Length)
    {
        $datadisks = $availabledisks[0..($NumberOfDisks-1)]
    }
    else
    {
        $datadisks = $availabledisks
    }
    
    Write-Verbose -Message "Creating Storage Pool - '$StoragePoolName'"
    New-StoragePool -FriendlyName $StoragePoolName -StorageSubSystemUniqueId (Get-StorageSubSystem -FriendlyName '*Space*').uniqueID -PhysicalDisks ($datadisks)
    Start-Sleep 20

    Write-Verbose -Message "Creating Virtual Disk '$VirtualDiskName' for Storage Pool - '$StoragePoolName'"
    New-VirtualDisk -FriendlyName $VirtualDiskName -StoragePoolFriendlyName $StoragePoolName -UseMaximumSize -AutoNumberOfColumns -ProvisioningType Fixed -ResiliencySettingName Simple
    Start-Sleep 20

    Write-Verbose -Message "Initializing the Virtual Disk '$VirtualDiskName'"
    Initialize-Disk -VirtualDisk (Get-VirtualDisk -FriendlyName $VirtualDiskName)
    Start-Sleep 20

    $diskNumber = ((Get-VirtualDisk -FriendlyName $VirtualDiskName | Get-Disk).Number)
    
    Write-Verbose -Message "Creating Partition on Virtual Disk '$VirtualDiskName'"
    New-Partition -DiskNumber $diskNumber -UseMaximumSize -DriveLetter $DriveLetter
    Start-Sleep 20

    Write-Verbose -Message "Formatting drive '$DriveLetter'"
    Format-Volume -DriveLetter $DriveLetter -FileSystem NTFS -NewFileSystemLabel $VirtualDiskName -Confirm:$false -Force
    
    return $true
}

function Test-TargetResource
{
    [OutputType([System.Boolean])]
    param
    (
        [parameter(Mandatory = $true)] [System.String] $StoragePoolName,
        [parameter(Mandatory = $true)] [System.String] $VirtualDiskName,
        [parameter(Mandatory = $true)] [System.UInt64] $NumberOfDisks,
        [parameter(Mandatory = $true)] [System.String] $DriveLetter,
        [ValidateNotNullOrEmpty()] [Bool]$RebootVirtualMachine = $false 
    )
    
    $result = [System.Boolean]
    Try 
    {
        $volume = Get-Volume $DriveLetter -ErrorAction Ignore
        if ($volume) 
        {
            Write-Verbose "'$DriveLetter' exists on target."
            $result = $true
        }
        else
        {
            Write-Verbose "'$DriveLetter' can't be found."
            $result = $false
        }
    }
    Catch 
    {
        throw "An error occured getting the '$DriveLetter' drive informations. Error: $($_.Exception.Message)"
    }

    $result    
}


Export-ModuleMember -Function *-TargetResource
