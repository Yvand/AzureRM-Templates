# Description

**Type:** Distributed

This resource is responsible for managing the user permissions for a web
application. You can either specify to set all permissions or specify
individual permissions per category.

More info about the permission levels:
