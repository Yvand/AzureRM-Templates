@{
    # Version number of this module.
    moduleVersion     = '3.0.1'

    # ID used to uniquely identify this module
    GUID              = '5f70e6a1-f1b2-4ba0-8276-8967d43a7ec2'

    # Author of this module
    Author            = 'DSC Community'

    # Company or vendor of this module
    CompanyName       = 'DSC Community'

    # Copyright statement for this module
    Copyright         = 'Copyright the DSC Community contributors. All rights reserved.'

    # Description of the functionality provided by this module
    Description       = 'This module contains DSC resources for the management and configuration of Windows Server DNS Server.'

    # Minimum version of the Windows PowerShell engine required by this module
    PowerShellVersion = '5.0'

    # Script module or binary module file associated with this manifest.
    RootModule = 'DnsServerDsc.psm1'

    # Functions to export from this module
    FunctionsToExport = @()

    # Cmdlets to export from this module
    CmdletsToExport   = @()

    # Variables to export from this module
    VariablesToExport = @()

    # Aliases to export from this module
    AliasesToExport   = @()

    DscResourcesToExport = @('DnsRecordCname','DnsRecordPtr','DnsRecordA','DnsRecordAaaa','DnsRecordMx','DnsRecordNs','DnsRecordSrv','DnsServerCache','DnsServerDsSetting','DnsServerEDns','DnsServerRecursion','DnsServerScavenging','DnsRecordAaaaScoped','DnsRecordAScoped','DnsRecordCnameScoped','DnsRecordMxScoped','DnsRecordNsScoped','DnsRecordSrvScoped','DnsServerADZone','DnsServerClientSubnet','DnsServerConditionalForwarder','DnsServerDiagnostics','DnsServerForwarder','DnsServerPrimaryZone','DnsServerRootHint','DnsServerSecondaryZone','DnsServerSetting','DnsServerSettingLegacy','DnsServerZoneAging','DnsServerZoneScope','DnsServerZoneTransfer')

    <#
      Private data to pass to the module specified in RootModule/ModuleToProcess.
      This may also contain a PSData hashtable with additional module metadata used by PowerShell.
    #>
    PrivateData       = @{
        PSData = @{
            # Set to a prerelease string value if the release should be a prerelease.
            Prerelease   = ''

            # Tags applied to this module. These help with module discovery in online galleries.
            Tags         = @('DesiredStateConfiguration', 'DSC', 'DSCResourceKit', 'DSCResource')

            # A URL to the license for this module.
            LicenseUri   = 'https://github.com/dsccommunity/DnsServerDsc/blob/main/LICENSE'

            # A URL to the main website for this project.
            ProjectUri   = 'https://github.com/dsccommunity/DnsServerDsc'

            # A URL to an icon representing this module.
            IconUri = 'https://dsccommunity.org/images/DSC_Logo_300p.png'

            # ReleaseNotes of this module
            ReleaseNotes = '## [3.0.1] - 2025-08-28

### Changed

- DnsServerDsc
  - Changed the issue template for reporting a problem with a resource to
    use the new GitHub issue forms template.
  - Changed the issue template for proposing a new resource to use the new
    GitHub issue forms template.
  - Replaced the private function `ConvertTo-HashTableFromObject` with the
    public function `ConvertFrom-DscResourceInstance` (from _DscResource.Common_).
  - Updated wiki start page with deprecation notice.
  - Updated issue template for proposing a new resource.
  - Removed left-over debug code.
  - Update to use the build worker `windows-latest` for the necessary stages
    of the pipeline, and `ubuntu-latest` for the other stages.
  - Update pipeline to use _GitVersion.Tool_ installed by `dotnet`.
  - Pin `gitversion` version in `azure-pipelines`
  - Update unit and integration tests to Pester 5
  - DnsServer* Class Resources
    - Used `DscResource.Base`
    - BREAKING: Added `Reasons` property as population of this is builtin
    to base class.
  - Updated `prefix`, `build`, `RequiredModules` for Pester 5 and
    DscResource.Base usage.
  - Added tests for `DSC_DnsServerSecondaryZone`.
  - Updated project related files
    - `.github/ISSUE_TEMPLATES`
    - `.vscode`
    - `ResolveDependency.ps1`
    - `build.ps1`
  - Change from using `Test-DnsDscParameterState`
  to `Test-DscParameterState` (from _DscResource.Common_).
  Fixes [[Issue #121](https://github.com/dsccommunity/DnsServerDsc/issues/121)].
  Affected resources:
    - `DSC_DnsServerDiagnostics`
    - `DSC_DnsServerRootHint`
- DnsServerDsc.Common
  - Added unit tests for `Convert-RootHintsToHashtable`.
- Revert to DscResource.Test 0.16.3.

### Fixed

- DnsRecordBase
  - Update comment regarding use of `using module` statement.
- ResourceBase
  - Update comment regarding use of `using module` statement.
- build.yaml
  - Replace `Generate_Wiki_Content` with `Generate_Markdown_For_DSC_Resources` to remove warning.
- DSC_DnsServerADZone
  - Use `New-ArgumentException` instead of `New-InvalidArgumentException`.
- DSC_DnsServerClientSubnet
  - Fixed wrong SYNAPSIS.
- DnsRecordCname
  - Fixed bug with dot at the end [[Issue #266](https://github.com/dsccommunity/DnsServerDsc/issues/266)].
- DnsRecordA
  - Fixed [[Issue #281](https://github.com/dsccommunity/DnsServerDsc/issues/281)].
- Pester tests
  - Fixed issue with local testing on systems with non en-US Culture in DSC_DnsServerRootHint
    unit test. It fixes [[Issue #283](https://github.com/dsccommunity/DnsServerDsc/issues/283)].
  - Fixed a typo in stream suppression causing Error stream to be suppressed when
    it was supposed not to be ([issue #274](https://github.com/dsccommunity/DnsServerDsc/issues/274)).
  - Fixed Unit test for DSC_DnsRecordPtr DSC resource. -ErrorMassage changed to -ErrorId ''InvalidCastParseTargetInvocation''.
- Styling
  - The use of Write-* cmdlets has been standardized to a consistent style with named parameters (-Message, -Object, etc).
  - *.tests.ps1 reindexed as *.Tests.ps1 for consistency.

### Removed

- DnsServerDsc.Common
  - Removed unit tests for functions no longer part of the module.
  - Removed functions from the module manifest that are no longer part of the module.
  - Unused function ConvertTo-FollowRfc1034 removed with corresponding tests.
  - Function Convert-RootHintsToHashtable moved to DSC_DnsServerRootHint.psm1
  - Unit test for Convert-RootHintsToHashtable moved from DnsServerDsc.Commom.Tests.ps1 to DSC_DnsServerRootHint.Tests.ps1.
  - Removed importing of DnsServerDsc.Common module from all resources.
  - Removed Modules directory from CopyPaths: block in build.yaml
  - DnsServerDsc.Common module complitely removed ([issue #282](https://github.com/dsccommunity/DnsServerDsc/issues/282)).
- DnsServerDsc
  - Removed `001.ResourceBase` and replaced with `DscResource.Base`.
  - Removed `Get-ClassName` and `Get-LocalizedDataRecursive` utilizing
    ones provided in `DscResource.Base`.
- DnsServerDsc.Common
  - Removed `Test-DnsDscParameterState` and associated localization entries.

'
        } # End of PSData hashtable
    } # End of PrivateData hashtable
}
