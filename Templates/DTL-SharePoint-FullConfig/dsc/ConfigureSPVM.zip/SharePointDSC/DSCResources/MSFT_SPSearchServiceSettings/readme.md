# Description

**Type:** Distributed
**Requires CredSSP:** No

This resource is responsible for configuring settings for the search
service, like the crawler performance level. All settings are farm
wide settings, which is why this resource should only be used once
in each configuration.
