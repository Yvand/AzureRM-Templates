# Description

**Type:** Distributed

This resource will deploy and configure a managed property in a specified search
service application.

The default value for the Ensure parameter is Present. When not specifying this
parameter, the managed property is created.
