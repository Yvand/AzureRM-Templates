# Description

The AdfsApplicationPermission DSC resource manages Application Permissions within Active Directory Federation
Services.

## Requirements

* Target machine must be running ADFS on Windows Server 2016 or above to use this resource.
