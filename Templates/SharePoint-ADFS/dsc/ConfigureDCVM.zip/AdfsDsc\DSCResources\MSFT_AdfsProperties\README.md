# Description

The AdfsProperties DSC resource manages all the associated properties for the Active Directory Federation
Services (AD FS) service.
