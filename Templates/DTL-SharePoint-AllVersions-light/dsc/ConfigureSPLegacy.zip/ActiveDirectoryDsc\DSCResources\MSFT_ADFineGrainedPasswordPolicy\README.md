# Description

The ADFineGrainedPasswordPolicy DSC resource will manage an Active Directory domain's fine grained password policies.

## Requirements

* Target machine must be running Windows Server 2012 or later.
